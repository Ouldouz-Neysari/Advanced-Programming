#ifndef _QUESTION_HPP_
#define _QUESTION_HPP_

#include<iostream>
#include<string>
#include<vector>

using namespace std;

class Question{
    public:
        virtual void submit_answer(vector<string>answer)=0;
        virtual void print_correct_ans()=0;
        virtual void print_student_ans()=0;
        Question(vector<string>question_info);
        int get_status();
        
    protected:
        string q_text;
        int status=0;
        vector<string>info;

};




#endif