#include"Q_short_answer.hpp"

const string CORR_ANS="correct answer.";
const string WRONG_ANS="wrong answer.";
const string STU_ANS="your answer: ";

short_answer_Q :: short_answer_Q(vector<string>question_info) : Question(question_info){
    q_text=question_info[1];
    answer=question_info[2];
}
void short_answer_Q :: set_answer(string ans_str){
    answer=ans_str;
}

void short_answer_Q :: submit_answer(vector<string>stu_answer){
    student_ans=stu_answer[0];
    if(student_ans==answer){
        cout<<CORR_ANS<<endl;
        status=1;
    }
    else{
        cout<<WRONG_ANS<<endl;   
        status=-1;
    }
}

void short_answer_Q :: print_correct_ans(){
    cout<<"correct answer: ";
    cout<<answer;
}
void short_answer_Q :: print_student_ans(){
    cout<<STU_ANS;
    cout<<student_ans<<endl;
}