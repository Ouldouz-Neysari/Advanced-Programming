#include"question.hpp"
#include<vector>
#include"question.hpp"

using namespace std;

class Exam{
    public:
        Exam();
        void analyzing_input(vector<vector<string>>input);
        void set_single_choice_ans(vector<string>this_q,int index);
        void set_multiple_choice_ans(vector<string>this_q,int index);
        void set_short_answer_ans(vector<string>this_q,int index);
        void submitting_answer(int question_num,vector<string>q_answer);
        void finish_exam();
        int calculate_answered_questions();
        float calculate_grade(float question_num,float correct_num);
    private:
        vector<Question*>exam_Qs;
        float grade;
};