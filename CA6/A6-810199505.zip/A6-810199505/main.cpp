#include"test.hpp"
#include"multiple_answer.hpp"
#include"Q_short_answer.hpp"
#include"question.hpp"
#include"exam.hpp"


#include<fstream>
#include<iostream>
#include<sstream>
#include<vector>
#include<string>

using namespace std;

const string DEL="#";
const string SUBMIT="submit_answer";
const string FINISH="finish_exam";

vector<vector<string>> getting_input(string file_name){
    string temp_str;
    vector<vector<string>>input;
    string trash;
    ifstream MyReadFile(file_name);
    vector<string>temp_vec;
    while (getline (MyReadFile, temp_str)) {
        if (MyReadFile.eof()){
            input.push_back(temp_vec);
            temp_vec.clear();
        }
        if(temp_str==DEL){
            input.push_back(temp_vec);
            temp_vec.clear();
            trash=temp_str;
        }
        else
            temp_vec.push_back(temp_str);
    }
    MyReadFile.close();
    return input;
}
vector<string>getting_command(){
    vector<string>commands;
    string temp_str;
    while (getline (cin, temp_str)) {
        commands.push_back(temp_str);
    }
    return commands;
}
vector<vector<string>> splitting_commands(vector<string>commands){
    vector<vector<string>>splitted_commands;
    vector<string>temp_vec;
    for(int i=0;i<commands.size();i++){
        std ::string temp_str;
        stringstream X(commands[i]);
        while (getline(X, temp_str, ' ')) {
            temp_vec.push_back(temp_str);
        }
        splitted_commands.push_back(temp_vec);
        temp_vec.clear();
    }
    return splitted_commands;

}
void processing_commands(vector<vector<string>>splitted_commands,Exam * my_Exam){
    for(int i=0;i<splitted_commands.size();i++){
        if(splitted_commands[i][0]==SUBMIT){
          my_Exam->submitting_answer(stoi(splitted_commands[i][1])-1,splitted_commands[i]);
        }
        if(splitted_commands[i][0]==FINISH){
            my_Exam->finish_exam();
        }
        
    }

}

int main(int argc,char * argv[]){
    vector<vector<string>>input=getting_input(argv[1]+2);
    Exam* my_Exam=new Exam();
    my_Exam->analyzing_input(input);
    vector<string>commands=getting_command();
    vector<vector<string>>splitted_commands=splitting_commands(commands);
    processing_commands(splitted_commands,my_Exam);
    return 0;

}