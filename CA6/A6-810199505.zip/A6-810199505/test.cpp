#include"test.hpp"
const string CORR_ANS="correct answer.";
const string WRONG_ANS="wrong answer.";
const string STU_ANS="your answer: ";

test :: test(vector<string>question_info) : Question(question_info){
    q_text=question_info[1];
    vector<string>q_choices;
    for(int i=0;i<stoi(question_info[2]);i++){
        q_choices.push_back(question_info[3+i]);
    }
    correct_answer_index=stoi(question_info[question_info.size()-1]);
    choices=q_choices;
}

void test :: set_answer(vector<string>q_choices,int answer_index){
    choices=q_choices;
    correct_answer_index=answer_index;
}

void test :: submit_answer(vector<string>answer){
    student_ans=answer;
    if(stoi(answer[0])==correct_answer_index){
        cout<<CORR_ANS<<endl;
        status=1;
    }
    else{
        cout<<WRONG_ANS<<endl;   
        status=-1;
    }
}

void test :: print_correct_ans(){
    cout<<"correct answer: "<<correct_answer_index;
}
void test :: print_student_ans(){
    cout<<STU_ANS<<student_ans[0]<<endl;
}