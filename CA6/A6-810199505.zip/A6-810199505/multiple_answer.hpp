#ifndef _MU_QUESTION_HPP_
#define _MU_QUESTION_HPP_
#include<iostream>
#include<string>
#include "question.hpp"

using namespace std;

class multiple_answer_question : public Question{
    public:
        multiple_answer_question(vector<string>text);
        void set_answer(vector<string>q_choices,int answer_index);
        virtual void submit_answer(vector<string>answer);
        virtual void print_correct_ans();
        virtual void print_student_ans();
        bool checking_answer_correctness(vector<string>answer);
        bool contains_this_element(string this_element);
        
    private:
        vector<string>student_ans;
        vector<string>choices;
        vector<string>correct_answer_indexs;

};




#endif