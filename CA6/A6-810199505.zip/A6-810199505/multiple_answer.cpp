#include"multiple_answer.hpp"
#include<sstream>

const string CORR_ANS="correct answer.";
const string WRONG_ANS="wrong answer.";
const string STU_ANS="your answer: ";

multiple_answer_question :: multiple_answer_question(vector<string>question_info) : Question(question_info){
    q_text=question_info[1];
    vector<string>q_choices;
    vector<string>correct_choices;
    for(int i=0;i<stoi(question_info[2]);i++){
        q_choices.push_back(question_info[3+i]);
    }
    string correct_indexs=question_info[question_info.size()-1];
    vector<string>temp_vec;
    stringstream X(correct_indexs);
    string temp_str;
    while (getline(X, temp_str, ' ')) {
        temp_vec.push_back(temp_str);
    }
    choices=q_choices;
    correct_answer_indexs=temp_vec;
}
bool multiple_answer_question :: contains_this_element(string this_element){
    for(int i=0;i<correct_answer_indexs.size();i++){
        if(correct_answer_indexs[i]==this_element){
            return true;
        }
    }
    return false;
}

bool multiple_answer_question ::checking_answer_correctness(vector<string>answer){
    int checker=0;
    if(answer.size()!=correct_answer_indexs.size()){
        return false;
    }
    else{
        for(int i=0;i<answer.size();i++){
        if(contains_this_element(answer[i]))
            checker+=1;
        }
        if(correct_answer_indexs.size()==checker)
            return true;
        else
            return false;

    }
    
}

void multiple_answer_question :: submit_answer(vector<string>answer){
    student_ans=answer;
    bool correct_checker=checking_answer_correctness(answer);
    if(correct_checker){
        cout<<CORR_ANS<<endl;
        status=1;
    }
    else{
        cout<<WRONG_ANS<<endl;   
        status=-1;
    }
}

void multiple_answer_question :: print_correct_ans(){
    cout<<"correct answer:";
    for(int i=0;i<correct_answer_indexs.size();i++){
        cout<<" "<<correct_answer_indexs[i];
    }
}
void multiple_answer_question :: print_student_ans(){
    cout<<STU_ANS;
    for(int i=0;i<student_ans.size();i++){
        cout<<student_ans[i]<<" ";
    }
    cout<<endl;
}