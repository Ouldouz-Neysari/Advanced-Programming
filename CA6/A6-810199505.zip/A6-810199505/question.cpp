#include"question.hpp"
Question :: Question(vector<string>text){
}
int Question:: get_status(){
    return status;
}