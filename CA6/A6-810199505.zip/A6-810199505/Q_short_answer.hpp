#ifndef _SH_QUESTION_HPP_
#define _SH_QUESTION_HPP_


#include<iostream>
#include<string>
#include"question.hpp"

using namespace std;

class short_answer_Q : public Question{
    public:
        short_answer_Q(vector<string>question_info);
        void set_answer(string ans_str);
        virtual void submit_answer(vector<string>ans);
        virtual void print_correct_ans();
        virtual void print_student_ans();
        
    private:
        string q_text;
        string answer;
        string student_ans;
};




#endif