#include"exam.hpp"
#include"question.hpp"
#include"test.hpp"
#include<vector>
#include"multiple_answer.hpp"
#include"Q_short_answer.hpp"

using namespace std;

const string SINGLE="single_answer";
const string MULTIPLE="multiple_answer";
const string SHORT_ANSWER="short_answer";
const string CORRECT="correct";
const string WRONG="wrong | ";
const string No_ANS="no answer | ";
Exam :: Exam (){
    grade=0;
}

void Exam ::analyzing_input(vector<vector<string>>input){
    Exam my_exam;
    for(int i=0;i<input.size();i++){
        if(input[i][0]==SINGLE){
            test * this_q=new test(input[i]);
            exam_Qs.push_back(this_q);
        }
        else if(input[i][0]==MULTIPLE){
            multiple_answer_question * this_q=new multiple_answer_question(input[i]);
            exam_Qs.push_back(this_q);
        }
        else if (input[i][0]==SHORT_ANSWER){
            short_answer_Q * this_q=new short_answer_Q(input[i]);
            exam_Qs.push_back(this_q);
        }
    }
}
int Exam :: calculate_answered_questions(){
    int answered_num=0;
    for (int i=0;i<exam_Qs.size();i++){
        if(exam_Qs[i]->get_status()!=0)
            answered_num+=1;
    }
    return answered_num;

}

void Exam :: submitting_answer(int question_num,vector<string>q_answer){
    vector<string>answer;
    for(int i=2;i<q_answer.size();i++){
        answer.push_back(q_answer[i]);
    }
    exam_Qs[question_num]->submit_answer(answer);
    if(calculate_answered_questions()==exam_Qs.size()){
        finish_exam();
    }
}
float Exam :: calculate_grade(float question_num,float correct_num){
    return (correct_num/question_num)*100;
}
void Exam :: finish_exam(){
    int correct_counter=0;
    for(int i=0;i<exam_Qs.size();i++){
        int Q_status=exam_Qs[i]->get_status();
        cout<<i+1<<" ";
        if(Q_status==1){
            cout<<CORRECT<<endl;
            correct_counter+=1;
        }
        else if (Q_status==-1){
            cout<<WRONG;
            exam_Qs[i]->print_correct_ans();
            cout<<", ";
            exam_Qs[i]->print_student_ans();
        }
        else {
            cout<<No_ANS;
            exam_Qs[i]->print_correct_ans();
            cout<<endl;
        }
    }
    cout.precision(1);
    cout<<"final grade: "<<fixed<<(float)calculate_grade(float(exam_Qs.size()),float(correct_counter))<<endl;
}
