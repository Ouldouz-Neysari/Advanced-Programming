#ifndef _TEST_HPP_
#define _TEST_HPP_

#include<iostream>
#include<string>
#include<vector>
#include"question.hpp"

using namespace std;

class test : public Question{
    public:
        test(vector<string>question_info);
        void set_answer(vector<string>q_choices,int answer_index);
        virtual void submit_answer(vector<string>answer);
        virtual void print_correct_ans();
        virtual void print_student_ans();
        
    private:
        vector<string>choices;
        vector<string>student_ans;
        int correct_answer_index;

};




#endif