#include<iostream>
#include<string>
#include<vector>

using namespace std;

string inverting(string S, string temp) {
	if (S.size() > 0) {
		if (S[0] == '1')
			temp = "0";
		else
			temp = "1";
		S = temp + inverting(S.substr(1), "");
	}
	return S;
}
string reversing(string S) {
	if (S.size() > 1) {
		S = reversing(S.substr(1)) + S[0];
	}
	return S;

}
string str_n(int n) {
	if (n > 1)
		return(str_n(n - 1) + "1" + reversing(inverting(str_n(n - 1), "")));
	else
		return("0");
}

int main() {
	int n, k;
	cin >> n;
	cin >> k;
	string string_n = str_n(n);
	cout << string_n[k - 1];
	getchar();
}