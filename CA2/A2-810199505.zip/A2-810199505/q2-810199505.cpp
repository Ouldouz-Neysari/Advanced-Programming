#include<iostream>
#include<string>
#include<vector>

using namespace std;

#define MAX_NUMBER_ASCII 58
#define MIN_NUMBER_ASCII 47

string int_start(string &secret_str, int n) {
	int i = 1;
	string temp = "";
	string return_str = "";
	if (secret_str[0] > MIN_NUMBER_ASCII && secret_str[0] < MAX_NUMBER_ASCII) {
		n = n * 10;
		n += (int(secret_str[0]) - 48);
		secret_str = secret_str.substr(1);
		string first_step = int_start(secret_str, n);
		return_str += first_step;
	}
	else {
		while (secret_str[i] != ']') {
			if (secret_str[i]> MIN_NUMBER_ASCII && secret_str[i]< MAX_NUMBER_ASCII) {
				int t = int(secret_str[i]) - 48;
				secret_str = secret_str.substr(i + 1);
				string return_str = int_start(secret_str, t);
				i = 0;
				temp = temp + return_str;
			}
			else {
				temp = temp + secret_str[i];
				i++;
			}
		}
		int j = 0;
		for (j = 0; j <n; j++) {
			return_str = return_str + temp;
		}
		secret_str = secret_str.substr(i + 1);
	}
	return return_str;
}

string str_n(string secret_str, int number) {
	string final_str;
	if (secret_str.size() == 1 || secret_str.size() == 0)
		return secret_str;
	else {
		char first_char = secret_str[0];
		secret_str = secret_str.substr(1);
		if (first_char> MIN_NUMBER_ASCII && first_char< MAX_NUMBER_ASCII) {
			number = int(first_char) - 48;
			string first_step = int_start(secret_str, number);
			return first_step + str_n(secret_str, number);
		}
		else
			return first_char + str_n(secret_str, number);
	}
}

int main() {
	string secret_str;
	cin >> secret_str;
	int number = 0;
	string final_string = str_n(secret_str, number);
	cout << final_string;
	return 0;
}