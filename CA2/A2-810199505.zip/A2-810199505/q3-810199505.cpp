#include<iostream>
#include<vector>
#include<string>

using namespace std;

void word_get(vector<string>&words) {
	char c;
	string temp;
	while (true) {
		getline(cin, temp);
		if (temp == "###")
			break;
		else
			words.push_back(temp);
	}
}

void string_get(vector<string>&strings) {
	char c;
	string temp;
	while (cin >> temp) {
		strings.push_back(temp);
	}
}
int starts_with(string str, string word, vector<string>words_in_str) {
	if (word == "")
		return 1;
	else {
		if (str[0] == word[0]) {
			int checker = starts_with(str.substr(1), word.substr(1), words_in_str);
			if (checker == 1)
				return 1;
			else
				return 0;
		}
		else
			return 0;
	}
}
int is_dividable(string str, vector<string>words, vector<string>&words_in_str) {
	if (str == "")
		return 1;
	int word_num = words.size();
	for (int i = 0; i < word_num; i++) {
		if (starts_with(str, words[i], words_in_str) == 1) {
			if (is_dividable(str.substr(words[i].size()), words, words_in_str) == 1) {
				words_in_str.push_back(words[i]);
				return 1;
			}
		}

	}

}
void word_print(vector<string>&words_in_str) {
	int length = words_in_str.size();
	for (int i = 1; i < length; i++) {
		cout << words_in_str[words_in_str.size() - 1] << " ";
		words_in_str.pop_back();
	}
	cout << words_in_str[0] << endl << "***" << endl;

}
void string_analyze(vector<string>strings, vector<string>words) {
	int string_num = strings.size();

	int checker;
	for (int i = 0; i < string_num; i++) {
		vector<string>words_in_str;
		checker = is_dividable(strings[i], words, words_in_str);
		if (checker == 1)
			word_print(words_in_str);
		else
			cout << "-1" << endl << "***" << endl;
	}
}

int main() {
	vector<string>words;
	vector<string>strings;
	word_get(words);
	string_get(strings);
	string_analyze(strings, words);
}